﻿namespace WiredBrainCoffeeAdmin.Data.Models
{
    public class SurveyItem
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }
}
